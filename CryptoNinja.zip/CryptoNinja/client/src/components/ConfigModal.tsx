import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Operation } from "@/lib/cryptoOperations";

interface ConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  operation: Operation | null;
  onApply: (config: Record<string, any>) => void;
}

export default function ConfigModal({ isOpen, onClose, operation, onApply }: ConfigModalProps) {
  const [config, setConfig] = useState<Record<string, any>>({});

  useEffect(() => {
    if (operation) {
      setConfig(operation.config || {});
    }
  }, [operation]);

  const handleApply = () => {
    onApply(config);
    onClose();
  };

  const handleConfigChange = (key: string, value: any) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  if (!operation) return null;

  const renderConfigFields = () => {
    switch (operation.type) {
      case "aes-encrypt":
      case "aes-decrypt":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="aes-key">AES Key</Label>
              <Input
                id="aes-key"
                type="password"
                placeholder="Enter AES key"
                value={config.key || ""}
                onChange={(e) => handleConfigChange("key", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="aes-mode">Mode</Label>
              <Select value={config.mode || "ECB"} onValueChange={(value) => handleConfigChange("mode", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select mode" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ECB">ECB</SelectItem>
                  <SelectItem value="CBC">CBC</SelectItem>
                  <SelectItem value="CFB">CFB</SelectItem>
                  <SelectItem value="OFB">OFB</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );
      
      case "base64-encode":
      case "base64-decode":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="input-format">Input Format</Label>
              <Select value={config.inputFormat || "utf8"} onValueChange={(value) => handleConfigChange("inputFormat", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select input format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="utf8">UTF-8</SelectItem>
                  <SelectItem value="ascii">ASCII</SelectItem>
                  <SelectItem value="binary">Binary</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="remove-linebreaks"
                checked={config.removeLinebreaks || false}
                onCheckedChange={(checked) => handleConfigChange("removeLinebreaks", checked)}
              />
              <Label htmlFor="remove-linebreaks">Remove line breaks</Label>
            </div>
          </div>
        );

      case "xor-cipher":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="xor-key">XOR Key</Label>
              <Input
                id="xor-key"
                type="text"
                placeholder="Enter XOR key"
                value={config.key || ""}
                onChange={(e) => handleConfigChange("key", e.target.value)}
              />
            </div>
          </div>
        );

      case "vigenere-encode":
      case "vigenere-decode":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="vigenere-key">Vigenère Key</Label>
              <Input
                id="vigenere-key"
                type="text"
                placeholder="Enter Vigenère key"
                value={config.key || ""}
                onChange={(e) => handleConfigChange("key", e.target.value)}
              />
            </div>
          </div>
        );

      case "rsa-encrypt":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="rsa-public-key">RSA Public Key (PEM format)</Label>
              <Input
                id="rsa-public-key"
                type="text"
                placeholder="-----BEGIN PUBLIC KEY-----..."
                value={config.publicKey || ""}
                onChange={(e) => handleConfigChange("publicKey", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="rsa-padding">Padding</Label>
              <Select value={config.padding || "OAEP"} onValueChange={(value) => handleConfigChange("padding", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select padding" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="OAEP">OAEP</SelectItem>
                  <SelectItem value="PKCS1">PKCS1</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case "rsa-decrypt":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="rsa-private-key">RSA Private Key (PEM format)</Label>
              <Input
                id="rsa-private-key"
                type="password"
                placeholder="-----BEGIN PRIVATE KEY-----..."
                value={config.privateKey || ""}
                onChange={(e) => handleConfigChange("privateKey", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="rsa-padding">Padding</Label>
              <Select value={config.padding || "OAEP"} onValueChange={(value) => handleConfigChange("padding", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select padding" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="OAEP">OAEP</SelectItem>
                  <SelectItem value="PKCS1">PKCS1</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case "random-string":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="string-length">Length</Label>
              <Input
                id="string-length"
                type="number"
                min="1"
                max="1000"
                placeholder="16"
                value={config.length || 16}
                onChange={(e) => handleConfigChange("length", parseInt(e.target.value) || 16)}
              />
            </div>
            <div>
              <Label htmlFor="charset">Character Set</Label>
              <Select value={config.charset || "alphanumeric"} onValueChange={(value) => handleConfigChange("charset", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select character set" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="alphanumeric">Alphanumeric</SelectItem>
                  <SelectItem value="alpha">Alphabetic</SelectItem>
                  <SelectItem value="numeric">Numeric</SelectItem>
                  <SelectItem value="hex">Hexadecimal</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case "regex-extract":
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="regex-pattern">Regex Pattern</Label>
              <Input
                id="regex-pattern"
                type="text"
                placeholder="Enter regex pattern"
                value={config.pattern || ""}
                onChange={(e) => handleConfigChange("pattern", e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="regex-flags">Flags</Label>
              <Input
                id="regex-flags"
                type="text"
                placeholder="g"
                value={config.flags || "g"}
                onChange={(e) => handleConfigChange("flags", e.target.value)}
              />
            </div>
          </div>
        );
      
      default:
        return (
          <div className="text-sm text-slate-500 dark:text-slate-400">
            No configuration options available for this operation.
          </div>
        );
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Configure {operation.name}</DialogTitle>
        </DialogHeader>
        
        <div className="py-4">
          {renderConfigFields()}
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleApply}>
            Apply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
