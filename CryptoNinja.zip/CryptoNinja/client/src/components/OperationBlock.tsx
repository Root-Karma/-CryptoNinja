import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Operation } from "@/lib/cryptoOperations";
import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface OperationBlockProps {
  operation: Operation;
  index: number;
  input: string;
  output: string;
  isSuccess: boolean;
  error?: string;
  onRemove: (index: number) => void;
  onConfigure: (index: number) => void;
}

export default function OperationBlock({
  operation,
  index,
  input,
  output,
  isSuccess,
  error,
  onRemove,
  onConfigure
}: OperationBlockProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging
  } = useSortable({ id: `operation-${index}` });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700 mb-2 shadow-sm"
    >
      <div className="flex items-center justify-between p-3 border-b border-slate-200 dark:border-slate-700">
        <div className="flex items-center space-x-3">
          <div className={`w-2 h-2 rounded-full ${isSuccess ? 'bg-green-500' : 'bg-red-500'}`}></div>
          <div>
            <h3 className="font-medium text-slate-900 dark:text-slate-100 text-sm">{operation.name}</h3>
          </div>
        </div>
        <div className="flex items-center space-x-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onConfigure(index)}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 h-6 w-6"
          >
            <i className="fas fa-cog text-xs"></i>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemove(index)}
            className="p-1 text-slate-400 hover:text-red-500 h-6 w-6"
          >
            <i className="fas fa-times text-xs"></i>
          </Button>
          <Button
            variant="ghost"
            size="sm"
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 cursor-move h-6 w-6"
            {...attributes}
            {...listeners}
          >
            <i className="fas fa-grip-vertical text-xs"></i>
          </Button>
        </div>
      </div>
      
      {error && (
        <div className="px-3 py-2 text-xs text-red-500 dark:text-red-400 bg-red-50 dark:bg-red-900/20">
          <i className="fas fa-exclamation-triangle mr-2"></i>
          {error}
        </div>
      )}
      
      {!error && input && (
        <div className="px-3 py-2 text-xs text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-700/50">
          <div className="flex items-center space-x-2">
            <span className="font-medium">Input:</span>
            <code className="px-2 py-1 bg-slate-100 dark:bg-slate-700 rounded font-mono text-xs max-w-xs truncate">
              {input.length > 50 ? input.substring(0, 50) + '...' : input}
            </code>
          </div>
        </div>
      )}
    </div>
  );
}
