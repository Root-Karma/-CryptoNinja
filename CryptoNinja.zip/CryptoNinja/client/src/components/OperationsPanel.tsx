import { useState } from "react";
import { availableOperations, operationCategories, getOperationsByCategory } from "@/lib/cryptoOperations";
import { useDraggable } from "@dnd-kit/core";
import { Input } from "@/components/ui/input";

interface DraggableOperationProps {
  operation: any;
}

function DraggableOperation({ operation }: DraggableOperationProps) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: operation.id,
    data: operation
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
    opacity: isDragging ? 0.5 : 1
  } : {};

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      className="p-2 bg-slate-50 dark:bg-slate-700 rounded cursor-grab active:cursor-grabbing hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors border border-slate-200 dark:border-slate-600"
    >
      <div className="text-xs font-medium text-slate-900 dark:text-slate-100">
        {operation.name}
      </div>
      <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">
        {operation.description}
      </div>
    </div>
  );
}

export default function OperationsPanel() {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredOperations = availableOperations.filter(op => 
    op.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    op.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getFilteredOperationsByCategory = (category: string) => {
    return getOperationsByCategory(category).filter(op => 
      op.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      op.description.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  return (
    <div className="h-full flex flex-col bg-white dark:bg-slate-800">
      <div className="p-3 border-b border-slate-200 dark:border-slate-700">
        <h2 className="text-sm font-medium text-slate-900 dark:text-slate-100 mb-3">Operations</h2>
        <div className="relative">
          <Input
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pr-8 text-xs h-8"
          />
          <i className="fas fa-search absolute right-3 top-2 text-slate-400 text-xs"></i>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {/* Favourites */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-star text-amber-500 mr-2 text-xs"></i>
            Favourites
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("favourites").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Data Format */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-code text-purple-500 mr-2 text-xs"></i>
            Data format
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("dataFormat").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Encryption / Encoding */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-lock text-blue-500 mr-2 text-xs"></i>
            Encryption / Encoding
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("encryption").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Public Key */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-key text-red-500 mr-2 text-xs"></i>
            Public Key
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("publicKey").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Compression */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-compress text-teal-500 mr-2 text-xs"></i>
            Compression
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("compression").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Hashing */}
        <div className="p-3 border-b border-slate-200 dark:border-slate-700">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-hashtag text-green-500 mr-2 text-xs"></i>
            Hashing
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("hashing").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>

        {/* Utils */}
        <div className="p-3">
          <h3 className="text-xs font-medium text-slate-700 dark:text-slate-300 mb-2 flex items-center">
            <i className="fas fa-tools text-orange-500 mr-2 text-xs"></i>
            Utils
          </h3>
          <div className="space-y-1">
            {getFilteredOperationsByCategory("utils").map((operation) => (
              <DraggableOperation key={operation.id} operation={operation} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
