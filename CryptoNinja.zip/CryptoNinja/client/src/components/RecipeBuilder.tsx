import { useState, useEffect } from "react";
import { useDroppable } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy, arrayMove } from "@dnd-kit/sortable";
import { Operation, executeOperation, getOperationById } from "@/lib/cryptoOperations";
import { Button } from "@/components/ui/button";
import OperationBlock from "./OperationBlock";
import ConfigModal from "./ConfigModal";

interface RecipeStep {
  id: string;
  operation: Operation;
  config?: Record<string, any>;
}

interface RecipeBuilderProps {
  operations: RecipeStep[];
  onOperationsChange: (operations: RecipeStep[]) => void;
  input: string;
  onOutputChange: (output: string) => void;
}

export default function RecipeBuilder({ operations, onOperationsChange, input, onOutputChange }: RecipeBuilderProps) {
  const [configModalOpen, setConfigModalOpen] = useState(false);
  const [configOperationIndex, setConfigOperationIndex] = useState<number | null>(null);
  const [operationResults, setOperationResults] = useState<Array<{
    input: string;
    output: string;
    isSuccess: boolean;
    error?: string;
  }>>([]);

  const { setNodeRef } = useDroppable({
    id: "recipe-builder"
  });

  // Process operations chain whenever input or operations change
  useEffect(() => {
    if (operations.length === 0) {
      onOutputChange(input);
      setOperationResults([]);
      return;
    }

    const results = [];
    let currentInput = input;

    for (let i = 0; i < operations.length; i++) {
      const operation = operations[i];
      const result = executeOperation(operation.operation, currentInput);
      
      results.push({
        input: currentInput,
        output: result.output,
        isSuccess: result.success,
        error: result.error
      });

      if (result.success) {
        currentInput = result.output;
      } else {
        // If operation fails, stop processing
        break;
      }
    }

    setOperationResults(results);
    onOutputChange(currentInput);
  }, [operations, input, onOutputChange]);

  const handleRemoveOperation = (index: number) => {
    const newOperations = operations.filter((_, i) => i !== index);
    onOperationsChange(newOperations);
  };

  const handleConfigureOperation = (index: number) => {
    setConfigOperationIndex(index);
    setConfigModalOpen(true);
  };

  const handleApplyConfig = (config: Record<string, any>) => {
    if (configOperationIndex !== null) {
      const newOperations = [...operations];
      newOperations[configOperationIndex] = {
        ...newOperations[configOperationIndex],
        operation: {
          ...newOperations[configOperationIndex].operation,
          config
        }
      };
      onOperationsChange(newOperations);
    }
  };

  const handleDragEnd = (event: any) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      const oldIndex = operations.findIndex(op => `operation-${operations.indexOf(op)}` === active.id);
      const newIndex = operations.findIndex(op => `operation-${operations.indexOf(op)}` === over.id);
      
      if (oldIndex !== -1 && newIndex !== -1) {
        const newOperations = arrayMove(operations, oldIndex, newIndex);
        onOperationsChange(newOperations);
      }
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="p-3 border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-medium text-slate-900 dark:text-slate-100">Recipe</h2>
          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-500 dark:text-slate-400">
              {operations.length} operation{operations.length !== 1 ? 's' : ''}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onOperationsChange([])}
              className="text-xs text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
            >
              <i className="fas fa-trash mr-1"></i>Clear
            </Button>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <div
          ref={setNodeRef}
          className="min-h-full p-4 bg-slate-50 dark:bg-slate-900"
        >
          {operations.length === 0 ? (
            <div className="text-center text-slate-500 dark:text-slate-400 py-16">
              <i className="fas fa-plus text-3xl mb-4 text-slate-300 dark:text-slate-600"></i>
              <p className="text-lg mb-2">Drag operations here to build your recipe</p>
              <p className="text-sm">Operations will be chained together automatically</p>
            </div>
          ) : (
            <SortableContext items={operations.map((_, index) => `operation-${index}`)} strategy={verticalListSortingStrategy}>
              <div className="space-y-2">
                {operations.map((step, index) => (
                  <OperationBlock
                    key={`operation-${index}`}
                    operation={step.operation}
                    index={index}
                    input={operationResults[index]?.input || ""}
                    output={operationResults[index]?.output || ""}
                    isSuccess={operationResults[index]?.isSuccess || false}
                    error={operationResults[index]?.error}
                    onRemove={handleRemoveOperation}
                    onConfigure={handleConfigureOperation}
                  />
                ))}
              </div>
            </SortableContext>
          )}
        </div>
      </div>

      <ConfigModal
        isOpen={configModalOpen}
        onClose={() => setConfigModalOpen(false)}
        operation={configOperationIndex !== null ? operations[configOperationIndex]?.operation : null}
        onApply={handleApplyConfig}
      />
    </div>
  );
}
