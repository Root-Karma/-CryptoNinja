import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { sampleDatasets } from "@/lib/sampleData";

interface SampleDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectSample: (data: string) => void;
}

export default function SampleDataModal({ isOpen, onClose, onSelectSample }: SampleDataModalProps) {
  const handleSelectSample = (data: string) => {
    onSelectSample(data);
    onClose();
  };

  const groupedSamples = sampleDatasets.reduce((acc, sample) => {
    if (!acc[sample.category]) {
      acc[sample.category] = [];
    }
    acc[sample.category].push(sample);
    return acc;
  }, {} as Record<string, typeof sampleDatasets>);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Sample Data</DialogTitle>
        </DialogHeader>
        
        <div className="py-4 max-h-96 overflow-y-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {sampleDatasets.map((sample) => (
              <div
                key={sample.id}
                className="p-4 bg-slate-50 dark:bg-slate-700 rounded-lg cursor-pointer hover:bg-slate-100 dark:hover:bg-slate-600 transition-colors"
                onClick={() => handleSelectSample(sample.data)}
              >
                <h4 className="font-medium text-slate-900 dark:text-slate-100 mb-2">
                  {sample.name}
                </h4>
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-2">
                  {sample.description}
                </p>
                <code className="text-xs font-mono text-slate-600 dark:text-slate-400 block truncate">
                  {sample.data}
                </code>
              </div>
            ))}
          </div>
        </div>
        
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
