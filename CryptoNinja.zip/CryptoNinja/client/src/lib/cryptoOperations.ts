import CryptoJS from "crypto-js";
import { SHA256 } from "crypto-js";
import { Base64 } from "js-base64";
import { sha3_256, sha3_512 } from "js-sha3";
import * as pako from "pako";
import LZString from "lz-string";
import * as forge from "node-forge";

export interface Operation {
  id: string;
  type: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  config?: Record<string, any>;
}

export interface OperationResult {
  success: boolean;
  output: string;
  error?: string;
}

export const operationCategories = {
  favourites: {
    name: "Favourites",
    icon: "fas fa-star",
    color: "text-amber-500"
  },
  encryption: {
    name: "Encryption / Encoding",
    icon: "fas fa-lock",
    color: "text-blue-500"
  },
  hashing: {
    name: "Hashing",
    icon: "fas fa-hashtag",
    color: "text-green-500"
  },
  dataFormat: {
    name: "Data Format",
    icon: "fas fa-code",
    color: "text-purple-500"
  },
  compression: {
    name: "Compression",
    icon: "fas fa-compress",
    color: "text-teal-500"
  },
  publicKey: {
    name: "Public Key",
    icon: "fas fa-key",
    color: "text-red-500"
  },
  utils: {
    name: "Utils",
    icon: "fas fa-tools",
    color: "text-orange-500"
  }
};

export const availableOperations: Operation[] = [
  // Favourites
  {
    id: "base64-encode",
    type: "base64-encode",
    name: "Base64 Encode",
    description: "Encode data using Base64",
    category: "favourites",
    icon: "fas fa-arrow-up",
    color: "bg-green-500"
  },
  {
    id: "sha256",
    type: "sha256",
    name: "SHA256",
    description: "SHA-256 hash",
    category: "favourites",
    icon: "fas fa-fingerprint",
    color: "bg-blue-500"
  },
  
  // Encryption / Encoding
  {
    id: "base64-decode",
    type: "base64-decode",
    name: "Base64 Decode",
    description: "Decode Base64 data",
    category: "encryption",
    icon: "fas fa-arrow-down",
    color: "bg-blue-500"
  },
  {
    id: "aes-encrypt",
    type: "aes-encrypt",
    name: "AES Encrypt",
    description: "AES encryption",
    category: "encryption",
    icon: "fas fa-lock",
    color: "bg-red-500",
    config: {
      key: "",
      mode: "ECB"
    }
  },
  {
    id: "aes-decrypt",
    type: "aes-decrypt",
    name: "AES Decrypt",
    description: "AES decryption",
    category: "encryption",
    icon: "fas fa-unlock",
    color: "bg-red-500",
    config: {
      key: "",
      mode: "ECB"
    }
  },
  {
    id: "hex-encode",
    type: "hex-encode",
    name: "To Hex",
    description: "Convert to hexadecimal",
    category: "encryption",
    icon: "fas fa-hashtag",
    color: "bg-yellow-500"
  },
  {
    id: "hex-decode",
    type: "hex-decode",
    name: "From Hex",
    description: "Convert from hexadecimal",
    category: "encryption",
    icon: "fas fa-hashtag",
    color: "bg-yellow-500"
  },
  {
    id: "rot13",
    type: "rot13",
    name: "ROT13",
    description: "ROT13 cipher",
    category: "encryption",
    icon: "fas fa-sync-alt",
    color: "bg-indigo-500"
  },
  {
    id: "url-encode",
    type: "url-encode",
    name: "URL Encode",
    description: "URL encode text",
    category: "encryption",
    icon: "fas fa-link",
    color: "bg-teal-500"
  },
  {
    id: "url-decode",
    type: "url-decode",
    name: "URL Decode",
    description: "URL decode text",
    category: "encryption",
    icon: "fas fa-unlink",
    color: "bg-teal-500"
  },

  // Hashing
  {
    id: "md5",
    type: "md5",
    name: "MD5",
    description: "MD5 hash",
    category: "hashing",
    icon: "fas fa-fingerprint",
    color: "bg-red-500"
  },
  {
    id: "sha1",
    type: "sha1",
    name: "SHA1",
    description: "SHA-1 hash",
    category: "hashing",
    icon: "fas fa-fingerprint",
    color: "bg-orange-500"
  },
  {
    id: "sha512",
    type: "sha512",
    name: "SHA512",
    description: "SHA-512 hash",
    category: "hashing",
    icon: "fas fa-fingerprint",
    color: "bg-purple-500"
  },

  // Data Format
  {
    id: "json-pretty",
    type: "json-pretty",
    name: "JSON Pretty",
    description: "Format JSON",
    category: "dataFormat",
    icon: "fas fa-code",
    color: "bg-blue-500"
  },
  {
    id: "json-minify",
    type: "json-minify",
    name: "JSON Minify",
    description: "Minify JSON",
    category: "dataFormat",
    icon: "fas fa-compress",
    color: "bg-blue-500"
  },

  // Utils
  {
    id: "reverse",
    type: "reverse",
    name: "Reverse",
    description: "Reverse text",
    category: "utils",
    icon: "fas fa-exchange-alt",
    color: "bg-gray-500"
  },
  {
    id: "uuid",
    type: "uuid",
    name: "Generate UUID",
    description: "Generate UUID",
    category: "utils",
    icon: "fas fa-id-card",
    color: "bg-cyan-500"
  },
  {
    id: "uppercase",
    type: "uppercase",
    name: "Uppercase",
    description: "Convert to uppercase",
    category: "utils",
    icon: "fas fa-font",
    color: "bg-slate-500"
  },
  {
    id: "lowercase",
    type: "lowercase",
    name: "Lowercase",
    description: "Convert to lowercase",
    category: "utils",
    icon: "fas fa-font",
    color: "bg-slate-500"
  },

  // Compression
  {
    id: "gzip-compress",
    type: "gzip-compress",
    name: "Gzip Compress",
    description: "Compress data using Gzip",
    category: "compression",
    icon: "fas fa-compress",
    color: "bg-teal-500"
  },
  {
    id: "gzip-decompress",
    type: "gzip-decompress",
    name: "Gzip Decompress",
    description: "Decompress Gzip data",
    category: "compression",
    icon: "fas fa-expand",
    color: "bg-teal-500"
  },
  {
    id: "lz-compress",
    type: "lz-compress",
    name: "LZ Compress",
    description: "Compress using LZ-String",
    category: "compression",
    icon: "fas fa-compress",
    color: "bg-cyan-500"
  },
  {
    id: "lz-decompress",
    type: "lz-decompress",
    name: "LZ Decompress",
    description: "Decompress LZ-String data",
    category: "compression",
    icon: "fas fa-expand",
    color: "bg-cyan-500"
  },

  // Additional Hashing
  {
    id: "sha3-256",
    type: "sha3-256",
    name: "SHA3-256",
    description: "SHA3-256 hash",
    category: "hashing",
    icon: "fas fa-fingerprint",
    color: "bg-indigo-500"
  },
  {
    id: "sha3-512",
    type: "sha3-512",
    name: "SHA3-512",
    description: "SHA3-512 hash",
    category: "hashing",
    icon: "fas fa-fingerprint",
    color: "bg-violet-500"
  },

  // Additional Encoding
  {
    id: "base32-encode",
    type: "base32-encode",
    name: "Base32 Encode",
    description: "Encode data using Base32",
    category: "encryption",
    icon: "fas fa-arrow-up",
    color: "bg-emerald-500"
  },
  {
    id: "base32-decode",
    type: "base32-decode",
    name: "Base32 Decode",
    description: "Decode Base32 data",
    category: "encryption",
    icon: "fas fa-arrow-down",
    color: "bg-emerald-500"
  },
  {
    id: "xor-cipher",
    type: "xor-cipher",
    name: "XOR Cipher",
    description: "XOR encryption with key",
    category: "encryption",
    icon: "fas fa-times",
    color: "bg-pink-500",
    config: {
      key: ""
    }
  },
  {
    id: "vigenere-encode",
    type: "vigenere-encode",
    name: "Vigenère Encode",
    description: "Vigenère cipher encryption",
    category: "encryption",
    icon: "fas fa-spell-check",
    color: "bg-rose-500",
    config: {
      key: ""
    }
  },
  {
    id: "vigenere-decode",
    type: "vigenere-decode",
    name: "Vigenère Decode",
    description: "Vigenère cipher decryption",
    category: "encryption",
    icon: "fas fa-spell-check",
    color: "bg-rose-500",
    config: {
      key: ""
    }
  },

  // Public Key Operations
  {
    id: "rsa-encrypt",
    type: "rsa-encrypt",
    name: "RSA Encrypt",
    description: "RSA public key encryption",
    category: "publicKey",
    icon: "fas fa-key",
    color: "bg-red-500",
    config: {
      publicKey: "",
      padding: "OAEP"
    }
  },
  {
    id: "rsa-decrypt",
    type: "rsa-decrypt",
    name: "RSA Decrypt",
    description: "RSA private key decryption",
    category: "publicKey",
    icon: "fas fa-unlock",
    color: "bg-red-500",
    config: {
      privateKey: "",
      padding: "OAEP"
    }
  },

  // Additional Data Format
  {
    id: "xml-format",
    type: "xml-format",
    name: "XML Format",
    description: "Format XML data",
    category: "dataFormat",
    icon: "fas fa-code",
    color: "bg-amber-500"
  },
  {
    id: "csv-to-json",
    type: "csv-to-json",
    name: "CSV to JSON",
    description: "Convert CSV to JSON",
    category: "dataFormat",
    icon: "fas fa-exchange-alt",
    color: "bg-green-500"
  },
  {
    id: "json-to-csv",
    type: "json-to-csv",
    name: "JSON to CSV",
    description: "Convert JSON to CSV",
    category: "dataFormat",
    icon: "fas fa-exchange-alt",
    color: "bg-green-500"
  },

  // Additional Utils
  {
    id: "random-string",
    type: "random-string",
    name: "Random String",
    description: "Generate random string",
    category: "utils",
    icon: "fas fa-random",
    color: "bg-gray-500",
    config: {
      length: 16,
      charset: "alphanumeric"
    }
  },
  {
    id: "timestamp",
    type: "timestamp",
    name: "Timestamp",
    description: "Generate current timestamp",
    category: "utils",
    icon: "fas fa-clock",
    color: "bg-slate-500"
  },
  {
    id: "regex-extract",
    type: "regex-extract",
    name: "Regex Extract",
    description: "Extract using regex pattern",
    category: "utils",
    icon: "fas fa-search",
    color: "bg-indigo-500",
    config: {
      pattern: "",
      flags: "g"
    }
  }
];

export function executeOperation(operation: Operation, input: string): OperationResult {
  try {
    let output = "";

    switch (operation.type) {
      case "base64-encode":
        output = Base64.encode(input);
        break;
      
      case "base64-decode":
        output = Base64.decode(input);
        break;
      
      case "aes-encrypt":
        if (!operation.config?.key) {
          throw new Error("AES key is required");
        }
        const encrypted = CryptoJS.AES.encrypt(input, operation.config.key);
        output = encrypted.toString();
        break;
      
      case "aes-decrypt":
        if (!operation.config?.key) {
          throw new Error("AES key is required");
        }
        const decrypted = CryptoJS.AES.decrypt(input, operation.config.key);
        output = decrypted.toString(CryptoJS.enc.Utf8);
        break;
      
      case "hex-encode":
        output = CryptoJS.enc.Hex.stringify(CryptoJS.enc.Utf8.parse(input));
        break;
      
      case "hex-decode":
        output = CryptoJS.enc.Hex.parse(input).toString(CryptoJS.enc.Utf8);
        break;
      
      case "rot13":
        output = input.replace(/[A-Za-z]/g, (char) => {
          const start = char <= 'Z' ? 65 : 97;
          return String.fromCharCode(((char.charCodeAt(0) - start + 13) % 26) + start);
        });
        break;
      
      case "url-encode":
        output = encodeURIComponent(input);
        break;
      
      case "url-decode":
        output = decodeURIComponent(input);
        break;
      
      case "md5":
        output = CryptoJS.MD5(input).toString();
        break;
      
      case "sha1":
        output = CryptoJS.SHA1(input).toString();
        break;
      
      case "sha256":
        output = SHA256(input).toString();
        break;
      
      case "sha512":
        output = CryptoJS.SHA512(input).toString();
        break;
      
      case "json-pretty":
        const parsed = JSON.parse(input);
        output = JSON.stringify(parsed, null, 2);
        break;
      
      case "json-minify":
        const minified = JSON.parse(input);
        output = JSON.stringify(minified);
        break;
      
      case "reverse":
        output = input.split("").reverse().join("");
        break;
      
      case "uuid":
        output = crypto.randomUUID();
        break;
      
      case "uppercase":
        output = input.toUpperCase();
        break;
      
      case "lowercase":
        output = input.toLowerCase();
        break;
      
      // Compression operations
      case "gzip-compress":
        const compressed = pako.gzip(input);
        output = btoa(String.fromCharCode(...compressed));
        break;
      
      case "gzip-decompress":
        const compressedData = Uint8Array.from(atob(input), c => c.charCodeAt(0));
        const decompressed = pako.ungzip(compressedData);
        output = String.fromCharCode(...decompressed);
        break;
      
      case "lz-compress":
        output = LZString.compress(input) || "";
        break;
      
      case "lz-decompress":
        output = LZString.decompress(input) || "";
        break;
      
      // Additional hashing
      case "sha3-256":
        output = sha3_256(input);
        break;
      
      case "sha3-512":
        output = sha3_512(input);
        break;
      
      // Additional encoding
      case "base32-encode":
        output = base32Encode(input);
        break;
      
      case "base32-decode":
        output = base32Decode(input);
        break;
      
      case "xor-cipher":
        if (!operation.config?.key) {
          throw new Error("XOR key is required");
        }
        output = xorCipher(input, operation.config.key);
        break;
      
      case "vigenere-encode":
        if (!operation.config?.key) {
          throw new Error("Vigenère key is required");
        }
        output = vigenereCipher(input, operation.config.key, true);
        break;
      
      case "vigenere-decode":
        if (!operation.config?.key) {
          throw new Error("Vigenère key is required");
        }
        output = vigenereCipher(input, operation.config.key, false);
        break;
      
      // RSA operations
      case "rsa-encrypt":
        if (!operation.config?.publicKey) {
          throw new Error("RSA public key is required");
        }
        output = rsaEncrypt(input, operation.config.publicKey);
        break;
      
      case "rsa-decrypt":
        if (!operation.config?.privateKey) {
          throw new Error("RSA private key is required");
        }
        output = rsaDecrypt(input, operation.config.privateKey);
        break;
      
      // Data format operations
      case "xml-format":
        output = formatXml(input);
        break;
      
      case "csv-to-json":
        output = csvToJson(input);
        break;
      
      case "json-to-csv":
        output = jsonToCsv(input);
        break;
      
      // Additional utils
      case "random-string":
        const length = operation.config?.length || 16;
        const charset = operation.config?.charset || "alphanumeric";
        output = generateRandomString(length, charset);
        break;
      
      case "timestamp":
        output = new Date().toISOString();
        break;
      
      case "regex-extract":
        if (!operation.config?.pattern) {
          throw new Error("Regex pattern is required");
        }
        output = regexExtract(input, operation.config.pattern, operation.config.flags || "g");
        break;
      
      default:
        throw new Error(`Unknown operation: ${operation.type}`);
    }

    return { success: true, output };
  } catch (error) {
    return { 
      success: false, 
      output: "", 
      error: error instanceof Error ? error.message : "Unknown error occurred"
    };
  }
}

export function getOperationsByCategory(category: string): Operation[] {
  return availableOperations.filter(op => op.category === category);
}

export function getOperationById(id: string): Operation | undefined {
  return availableOperations.find(op => op.id === id);
}

// Helper functions for new operations
function base32Encode(input: string): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  let output = "";
  let buffer = 0;
  let bits = 0;
  
  for (let i = 0; i < input.length; i++) {
    buffer = (buffer << 8) | input.charCodeAt(i);
    bits += 8;
    
    while (bits >= 5) {
      output += alphabet[(buffer >> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  
  if (bits > 0) {
    output += alphabet[(buffer << (5 - bits)) & 31];
  }
  
  while (output.length % 8 !== 0) {
    output += "=";
  }
  
  return output;
}

function base32Decode(input: string): string {
  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  const lookup = Object.fromEntries(alphabet.split("").map((char, i) => [char, i]));
  
  input = input.replace(/=/g, "");
  let output = "";
  let buffer = 0;
  let bits = 0;
  
  for (let i = 0; i < input.length; i++) {
    const char = input[i].toUpperCase();
    if (!(char in lookup)) continue;
    
    buffer = (buffer << 5) | lookup[char];
    bits += 5;
    
    if (bits >= 8) {
      output += String.fromCharCode((buffer >> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  
  return output;
}

function xorCipher(input: string, key: string): string {
  let output = "";
  for (let i = 0; i < input.length; i++) {
    output += String.fromCharCode(input.charCodeAt(i) ^ key.charCodeAt(i % key.length));
  }
  return output;
}

function vigenereCipher(input: string, key: string, encrypt: boolean): string {
  let output = "";
  let keyIndex = 0;
  
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    
    if (char.match(/[a-zA-Z]/)) {
      const isUpperCase = char >= 'A' && char <= 'Z';
      const charCode = char.toUpperCase().charCodeAt(0) - 65;
      const keyChar = key[keyIndex % key.length].toUpperCase().charCodeAt(0) - 65;
      
      let newChar;
      if (encrypt) {
        newChar = (charCode + keyChar) % 26;
      } else {
        newChar = (charCode - keyChar + 26) % 26;
      }
      
      output += String.fromCharCode(newChar + 65);
      if (!isUpperCase) {
        output = output.slice(0, -1) + output.slice(-1).toLowerCase();
      }
      keyIndex++;
    } else {
      output += char;
    }
  }
  
  return output;
}

function rsaEncrypt(input: string, publicKeyPem: string): string {
  try {
    const publicKey = forge.pki.publicKeyFromPem(publicKeyPem);
    const encrypted = publicKey.encrypt(input, 'RSA-OAEP');
    return forge.util.encode64(encrypted);
  } catch (error) {
    throw new Error("Invalid public key or encryption failed");
  }
}

function rsaDecrypt(input: string, privateKeyPem: string): string {
  try {
    const privateKey = forge.pki.privateKeyFromPem(privateKeyPem);
    const encrypted = forge.util.decode64(input);
    const decrypted = privateKey.decrypt(encrypted, 'RSA-OAEP');
    return decrypted;
  } catch (error) {
    throw new Error("Invalid private key or decryption failed");
  }
}

function formatXml(input: string): string {
  try {
    const parser = new DOMParser();
    const doc = parser.parseFromString(input, "application/xml");
    const serializer = new XMLSerializer();
    const xmlString = serializer.serializeToString(doc);
    
    // Simple XML formatting
    let formatted = xmlString.replace(/></g, ">\n<");
    let indent = 0;
    const lines = formatted.split('\n');
    
    return lines.map(line => {
      if (line.includes('</') && !line.includes('</' + line.split('</')[1].split('>')[0] + '>')) {
        indent--;
      }
      const result = '  '.repeat(indent) + line;
      if (line.includes('<') && !line.includes('</') && !line.includes('?>') && !line.includes('/>')) {
        indent++;
      }
      return result;
    }).join('\n');
  } catch (error) {
    throw new Error("Invalid XML format");
  }
}

function csvToJson(input: string): string {
  const lines = input.trim().split('\n');
  if (lines.length < 2) {
    throw new Error("CSV must have at least a header and one data row");
  }
  
  const headers = lines[0].split(',').map(h => h.trim());
  const result = [];
  
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(',').map(v => v.trim());
    const obj: Record<string, string> = {};
    
    headers.forEach((header, index) => {
      obj[header] = values[index] || "";
    });
    
    result.push(obj);
  }
  
  return JSON.stringify(result, null, 2);
}

function jsonToCsv(input: string): string {
  const data = JSON.parse(input);
  if (!Array.isArray(data) || data.length === 0) {
    throw new Error("JSON must be an array of objects");
  }
  
  const headers = Object.keys(data[0]);
  const csvRows = [headers.join(',')];
  
  for (const row of data) {
    const values = headers.map(header => {
      const value = row[header] || "";
      return typeof value === 'string' && value.includes(',') ? `"${value}"` : value;
    });
    csvRows.push(values.join(','));
  }
  
  return csvRows.join('\n');
}

function generateRandomString(length: number, charset: string): string {
  let chars = "";
  
  switch (charset) {
    case "alphanumeric":
      chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
      break;
    case "alpha":
      chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
      break;
    case "numeric":
      chars = "0123456789";
      break;
    case "hex":
      chars = "0123456789ABCDEF";
      break;
    default:
      chars = charset;
  }
  
  let result = "";
  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}

function regexExtract(input: string, pattern: string, flags: string): string {
  try {
    const regex = new RegExp(pattern, flags);
    const matches = input.match(regex);
    return matches ? matches.join('\n') : "";
  } catch (error) {
    throw new Error("Invalid regex pattern");
  }
}
