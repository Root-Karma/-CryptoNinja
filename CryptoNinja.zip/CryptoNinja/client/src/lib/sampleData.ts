export interface SampleData {
  id: string;
  name: string;
  description: string;
  data: string;
  category: string;
}

export const sampleDatasets: SampleData[] = [
  {
    id: "base64-text",
    name: "Base64 Text",
    description: "Sample Base64 encoded text",
    data: "SGVsbG8sIFdvcmxkIQ==",
    category: "encoding"
  },
  {
    id: "hex-string",
    name: "Hex String",
    description: "Sample hexadecimal data",
    data: "48656c6c6f2c20576f726c6421",
    category: "encoding"
  },
  {
    id: "json-data",
    name: "JSON Data",
    description: "Sample JSON for formatting",
    data: '{"name":"John","age":30,"city":"New York","hobbies":["reading","coding","hiking"],"address":{"street":"123 Main St","country":"USA"}}',
    category: "format"
  },
  {
    id: "url-encoded",
    name: "URL Encoded",
    description: "Sample URL encoded string",
    data: "Hello%2C%20World%21%20This%20is%20a%20test%20string%20with%20special%20characters%3A%20%40%23%24%25%5E%26*()%2B%3D",
    category: "encoding"
  },
  {
    id: "plain-text",
    name: "Plain Text",
    description: "Simple plain text for testing",
    data: "Hello, World! This is a sample text with various characters: @#$%^&*()+=[]{}|;':\",./<>?",
    category: "text"
  },
  {
    id: "multiline-text",
    name: "Multi-line Text",
    description: "Sample multi-line text",
    data: "Line 1: This is the first line\nLine 2: This is the second line\nLine 3: This is the third line\n\nThis is a paragraph after a blank line.",
    category: "text"
  },
  {
    id: "hash-input",
    name: "Hash Test Input",
    description: "Text suitable for hashing operations",
    data: "The quick brown fox jumps over the lazy dog",
    category: "text"
  },
  {
    id: "aes-plaintext",
    name: "AES Plaintext",
    description: "Sample text for AES encryption",
    data: "This is a secret message that needs to be encrypted using AES.",
    category: "encryption"
  },
  {
    id: "vigenere-plaintext",
    name: "Vigenère Plaintext",
    description: "Sample text for Vigenère cipher",
    data: "HELLO WORLD THIS IS A SECRET MESSAGE",
    category: "encryption"
  },
  {
    id: "csv-data",
    name: "CSV Data",
    description: "Sample CSV data for conversion",
    data: "name,age,city\nJohn,30,New York\nJane,25,Los Angeles\nBob,35,Chicago",
    category: "format"
  },
  {
    id: "xml-data",
    name: "XML Data",
    description: "Sample XML data for formatting",
    data: "<root><person><name>John</name><age>30</age></person><person><name>Jane</name><age>25</age></person></root>",
    category: "format"
  },
  {
    id: "compressed-data",
    name: "Compressed Text",
    description: "Sample text for compression testing",
    data: "This is a longer text that can be compressed using various algorithms. It contains repetitive patterns and structures that compression algorithms can take advantage of to reduce the overall size.",
    category: "compression"
  },
  {
    id: "regex-test",
    name: "Email Extraction Test",
    description: "Text containing email addresses",
    data: "Contact us at support@example.com or sales@company.org. You can also reach admin@test.net for technical issues.",
    category: "text"
  }
];

export function getSampleDataByCategory(category: string): SampleData[] {
  return sampleDatasets.filter(sample => sample.category === category);
}

export function getSampleDataById(id: string): SampleData | undefined {
  return sampleDatasets.find(sample => sample.id === id);
}
