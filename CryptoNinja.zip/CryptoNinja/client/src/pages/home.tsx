import { useState } from "react";
import { DndContext, DragEndEvent, DragOverEvent } from "@dnd-kit/core";
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable";
import { useTheme } from "@/components/ThemeProvider";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import OperationsPanel from "@/components/OperationsPanel";
import RecipeBuilder from "@/components/RecipeBuilder";
import SampleDataModal from "@/components/SampleDataModal";
import { Operation, getOperationById } from "@/lib/cryptoOperations";

interface RecipeStep {
  id: string;
  operation: Operation;
  config?: Record<string, any>;
}

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const { toast } = useToast();
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [operations, setOperations] = useState<RecipeStep[]>([]);
  const [sampleModalOpen, setSampleModalOpen] = useState(false);

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && over.id === "recipe-builder") {
      const operationId = active.id as string;
      const operation = getOperationById(operationId);
      
      if (operation) {
        const newStep: RecipeStep = {
          id: `${Date.now()}-${Math.random()}`,
          operation: { ...operation }
        };
        setOperations(prev => [...prev, newStep]);
      }
    }
  };

  const handleCopyOutput = async () => {
    try {
      await navigator.clipboard.writeText(output);
      toast({
        title: "Copied to clipboard",
        description: "Output has been copied to your clipboard",
      });
    } catch (err) {
      toast({
        title: "Failed to copy",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const handleDownloadOutput = () => {
    const blob = new Blob([output], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cryptoninja-output.txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleClearRecipe = () => {
    setOperations([]);
    setOutput("");
  };

  const handleImportRecipe = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          try {
            const recipe = JSON.parse(e.target?.result as string);
            setOperations(recipe.operations || []);
            setInput(recipe.input || "");
            toast({
              title: "Recipe imported",
              description: "Recipe has been successfully imported",
            });
          } catch (err) {
            toast({
              title: "Import failed",
              description: "Invalid recipe file format",
              variant: "destructive",
            });
          }
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  const handleExportRecipe = () => {
    const recipe = {
      input,
      operations,
      exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(recipe, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "cryptoninja-recipe.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleUploadFile = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".txt,.json,.csv,.xml";
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
          setInput(e.target?.result as string);
        };
        reader.readAsText(file);
      }
    };
    input.click();
  };

  return (
    <DndContext onDragEnd={handleDragEnd}>
      <div className="min-h-screen bg-slate-50 dark:bg-slate-900 text-slate-900 dark:text-slate-100 transition-colors duration-300">
        {/* Header */}
        <header className="bg-white dark:bg-slate-800 shadow-sm border-b border-slate-200 dark:border-slate-700">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-shield-alt text-2xl text-primary"></i>
                  <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">CryptoNinja</h1>
                </div>
                <span className="text-sm text-slate-500 dark:text-slate-400">
                  Data Transformation & Cryptography Toolkit
                </span>
              </div>
              
              <div className="flex items-center space-x-4">
                {/* Theme Toggle */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={toggleTheme}
                  className="p-2"
                >
                  {theme === "light" ? (
                    <i className="fas fa-moon text-slate-600"></i>
                  ) : (
                    <i className="fas fa-sun text-slate-400"></i>
                  )}
                </Button>
                
                {/* Recipe Controls */}
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleImportRecipe}
                  >
                    <i className="fas fa-upload mr-1"></i>Import
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleExportRecipe}
                  >
                    <i className="fas fa-download mr-1"></i>Export
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleClearRecipe}
                    className="text-red-700 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
                  >
                    <i className="fas fa-trash mr-1"></i>Clear
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex h-[calc(100vh-64px)]">
          {/* Operations Panel - Fixed width sidebar */}
          <div className="w-64 flex-shrink-0 border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
            <OperationsPanel />
          </div>

          {/* Main Content Area */}
          <div className="flex-1 flex flex-col">
            {/* Recipe Builder */}
            <div className="flex-1 p-4 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900">
              <RecipeBuilder
                operations={operations}
                onOperationsChange={setOperations}
                input={input}
                onOutputChange={setOutput}
              />
            </div>

            {/* Input/Output Row */}
            <div className="flex h-80 border-b border-slate-200 dark:border-slate-700">
              {/* Input Section */}
              <div className="flex-1 border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
                <div className="p-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-medium text-slate-900 dark:text-slate-100">Input</h2>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleUploadFile}
                        className="text-xs"
                      >
                        <i className="fas fa-file-upload mr-1"></i>File
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setSampleModalOpen(true)}
                        className="text-xs"
                      >
                        <i className="fas fa-magic mr-1"></i>Sample
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="p-3 h-full">
                  <Textarea
                    placeholder="Enter your input here..."
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    className="h-full resize-none border-0 bg-transparent font-mono text-xs focus:ring-0 focus:border-0"
                  />
                </div>
              </div>

              {/* Output Section */}
              <div className="flex-1 bg-white dark:bg-slate-800">
                <div className="p-3 border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-700">
                  <div className="flex items-center justify-between">
                    <h2 className="text-sm font-medium text-slate-900 dark:text-slate-100">Output</h2>
                    <div className="flex items-center space-x-2">
                      <span className="text-xs text-slate-500 dark:text-slate-400">
                        {output.length} chars
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleCopyOutput}
                        className="text-xs"
                      >
                        <i className="fas fa-copy mr-1"></i>Copy
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleDownloadOutput}
                        className="text-xs"
                      >
                        <i className="fas fa-download mr-1"></i>Save
                      </Button>
                    </div>
                  </div>
                </div>
                <div className="p-3 h-full">
                  <Textarea
                    readOnly
                    value={output}
                    className="h-full resize-none border-0 bg-transparent font-mono text-xs focus:ring-0 focus:border-0"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sample Data Modal */}
        <SampleDataModal
          isOpen={sampleModalOpen}
          onClose={() => setSampleModalOpen(false)}
          onSelectSample={(data) => setInput(data)}
        />
      </div>
    </DndContext>
  );
}
