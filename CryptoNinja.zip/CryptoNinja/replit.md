# CryptoNinja - Data Transformation & Cryptography Toolkit

## Overview

CryptoNinja is a web-based cryptography and data transformation toolkit inspired by CyberChef. It provides a drag-and-drop interface for chaining cryptographic operations and data transformations in real-time. The application is built as a single-page application with client-side processing for security and performance.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: React Query for server state, local React state for UI
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Server**: Express.js with TypeScript (minimal backend)
- **Runtime**: Node.js with ES modules
- **Development**: Hot module replacement via Vite integration
- **API Structure**: RESTful endpoints under `/api` prefix

### UI/UX Architecture
- **Component System**: Radix UI primitives with custom Tailwind styling
- **Drag & Drop**: @dnd-kit for operation chaining interface
- **Theme System**: Light/dark mode with CSS variables
- **Responsive Design**: Mobile-first approach with breakpoint-based layouts

## Key Components

### Operations System
- **Operation Categories**: Favourites, Encryption/Encoding, Hashing, Data Format, Compression, Public Key, Utils
- **Operation Chaining**: Drag-and-drop recipe builder for sequential transformations
- **Real-time Processing**: Client-side computation with instant feedback
- **Configuration UI**: Modal-based parameter configuration for operations
- **Expanded Operations**: 40+ cryptographic and data transformation operations including:
  - Advanced encryption: AES, RSA, XOR, Vigenère cipher
  - Compression: Gzip, LZ-String
  - Modern hashing: SHA3-256, SHA3-512
  - Data formats: CSV/JSON conversion, XML formatting
  - Enhanced utilities: regex extraction, random string generation

### Core UI Components
- **OperationsPanel**: Searchable, categorized list of available operations
- **RecipeBuilder**: Drag-and-drop area for building operation chains
- **OperationBlock**: Individual operation components with configuration options
- **ConfigModal**: Dynamic configuration interface for operation parameters

### Data Processing
- **Crypto Operations**: AES, hashing (SHA-256, MD5), Base64, hex encoding
- **Sample Data**: Pre-defined test datasets for demonstration
- **Error Handling**: Graceful failure handling with user feedback

## Data Flow

1. **Input**: User provides input data via textarea
2. **Operation Selection**: User drags operations from panel to recipe builder
3. **Configuration**: Operations can be configured via modal interfaces
4. **Processing**: Data flows through operation chain sequentially
5. **Output**: Final result displayed in real-time with intermediate steps shown
6. **Feedback**: Success/error states communicated through UI components

## External Dependencies

### Core Libraries
- **Cryptography**: crypto-js for encryption/decryption operations
- **UI Components**: Radix UI for accessible component primitives
- **Styling**: Tailwind CSS for utility-first styling
- **Drag & Drop**: @dnd-kit for accessible drag-and-drop interactions

### Development Tools
- **TypeScript**: Static typing for improved developer experience
- **ESLint/Prettier**: Code quality and formatting
- **Vite**: Fast development server and build tool

### Database & Storage
- **Database**: PostgreSQL with Drizzle ORM and Neon serverless driver
- **Tables**: users, recipes, favourites with proper relations
- **Session Management**: User authentication with bcrypt password hashing
- **Client Storage**: Local storage for user preferences and favourites
- **API**: Full CRUD operations for recipes and favourites management

## Deployment Strategy

### Development
- **Local Development**: Vite dev server with hot module replacement
- **Environment**: NODE_ENV=development with development middleware
- **Database**: Memory-based storage for simplified development

### Production
- **Build Process**: Vite build for client, esbuild for server bundling
- **Static Assets**: Client files served from dist/public
- **Server**: Express server serving API and static files
- **Database**: PostgreSQL with connection pooling via Neon

### Configuration
- **Environment Variables**: DATABASE_URL for database connection
- **Build Scripts**: Separate dev, build, and start commands
- **Asset Handling**: Vite handles client asset optimization and bundling

The application is designed to be primarily client-side for security reasons, with minimal server-side functionality. All cryptographic operations are performed in the browser to ensure data privacy and security.