import { users, recipes, favourites, type User, type InsertUser, type Recipe, type InsertRecipe, type Favourite, type InsertFavourite } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Recipe operations
  getRecipesByUser(userId: number): Promise<Recipe[]>;
  getRecipe(id: number): Promise<Recipe | undefined>;
  createRecipe(userId: number, recipe: InsertRecipe): Promise<Recipe>;
  updateRecipe(id: number, userId: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined>;
  deleteRecipe(id: number, userId: number): Promise<boolean>;
  
  // Favourite operations
  getFavouritesByUser(userId: number): Promise<Favourite[]>;
  addFavourite(userId: number, favourite: InsertFavourite): Promise<Favourite>;
  removeFavourite(userId: number, operationId: string): Promise<boolean>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // Recipe operations
  async getRecipesByUser(userId: number): Promise<Recipe[]> {
    return await db.select().from(recipes).where(eq(recipes.userId, userId));
  }

  async getRecipe(id: number): Promise<Recipe | undefined> {
    const [recipe] = await db.select().from(recipes).where(eq(recipes.id, id));
    return recipe || undefined;
  }

  async createRecipe(userId: number, recipe: InsertRecipe): Promise<Recipe> {
    const [newRecipe] = await db
      .insert(recipes)
      .values({ ...recipe, userId })
      .returning();
    return newRecipe;
  }

  async updateRecipe(id: number, userId: number, recipe: Partial<InsertRecipe>): Promise<Recipe | undefined> {
    const [updatedRecipe] = await db
      .update(recipes)
      .set({ ...recipe, updatedAt: new Date() })
      .where(and(eq(recipes.id, id), eq(recipes.userId, userId)))
      .returning();
    return updatedRecipe || undefined;
  }

  async deleteRecipe(id: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(recipes)
      .where(and(eq(recipes.id, id), eq(recipes.userId, userId)));
    return (result.rowCount || 0) > 0;
  }

  // Favourite operations
  async getFavouritesByUser(userId: number): Promise<Favourite[]> {
    return await db.select().from(favourites).where(eq(favourites.userId, userId));
  }

  async addFavourite(userId: number, favourite: InsertFavourite): Promise<Favourite> {
    const [newFavourite] = await db
      .insert(favourites)
      .values({ ...favourite, userId })
      .returning();
    return newFavourite;
  }

  async removeFavourite(userId: number, operationId: string): Promise<boolean> {
    const result = await db
      .delete(favourites)
      .where(and(eq(favourites.userId, userId), eq(favourites.operationId, operationId)));
    return (result.rowCount || 0) > 0;
  }
}

export const storage = new DatabaseStorage();
